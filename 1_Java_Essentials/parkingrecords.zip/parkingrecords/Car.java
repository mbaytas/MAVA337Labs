
/**
 * Describes a car.
 * 
 * @author mbaytas
 * @version 2016-02-15
 */
public class Car
{
    // instance variables
    private String ownerName;
    private int ownerId;
    private String licencePlate;
    private boolean isFeePaid;
    private integer dryWeight;
    private integer totalWeight;
    

    /**
     * Constructor for objects of class Car
     */
    public Car(String initOwnerName, int initOwnerId, String initLicencePlate, boolean initIsFeePaid, int initDryWeight)
    {
        ownerName = initOwnerName;
        ownerId = initOwnerId;
        licencePlate = initLicencePlate;
        isFeePaid = initIsFeePaid;
        dryWeight = initDryWeight;
        totalWeight = calculateTotalWeight();
    }

    /**
     * Sets the ownerName.
     *
     * @param  newName   value to be assigned to "ownerName"
     */
    public void setOwnerName(String newName)
    {
        ownerName = newName;
    }
    
    /**
     * Sets the ownerId.
     *
     * @param  newOwnerID   value to be assigned to "ownerId"
     */    
    public void setOwnerId(int newId)
    {
        ownerId = newId;
    }
    
    /**
     * Sets the licencePlate.
     *
     * @param  newLicencePlate   value to be assigned to "licencePlate"
     */
    public void setLicencePlate(String newLicencePlate)
    {
        licencePlate = newLicencePlate;
    }
    
    /**
     * Sets the isFeePaid.
     *
     * @param  newIsFeePaid   value to be assigned to "isFeePaid"
     */
    public void setIsFeePaid(boolean newIsFeePaid)
    {
        isFeePaid = newIsFeePaid;
    }
    
    /**
     * Sets the dryWeight.
     *
     * @param  newDryWeight   value to be assigned to "dryWeight"
     */
    public void setDryWeight(int newDryWeight)
    {
        dryWeight = newDryWeight;
        totalWeight = calculateTotalWeight();
    }
    
    /**
     * XXXXXX
     *
     * sdfasdfasdfasdf!!!
     */
    public void calculateTotalWeight(int dryWeight)
    {
        return dryWeight + 500;
    }
}
